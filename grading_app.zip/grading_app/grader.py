# -*- coding: utf-8 -*-
"""
채점 로직
- 단순 키워드 매칭이 아니라, Claude API에 채점 기준(허용 동의어 범위/오개념 패턴/결론 방향 등)을
  통째로 넘겨 '의미' 기준으로 판단하게 한다.
- 모든 채점 함수는 동일한 형태의 결과 dict를 반환한다:
  {
    "total_score": float, "max_score": float,
    "items": [ {"name": str, "score": float, "max": float, "verdict": "정답"/"부분점수"/"오답",
                "reason": str, "misconception_flag": str|None} , ... ],
    "overall_feedback": str
  }
"""

import json
import os
import re

from anthropic import Anthropic

MODEL = "claude-sonnet-5"


def _client():
    api_key = os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("ANTHROPIC_KEY")
    if not api_key:
        raise RuntimeError(
            "ANTHROPIC_API_KEY 환경변수가 설정되어 있지 않습니다. "
            "터미널에서 `export ANTHROPIC_API_KEY=sk-...` 또는 .streamlit/secrets.toml에 등록하세요."
        )
    return Anthropic(api_key=api_key)


def _call_claude_json(system_prompt: str, user_prompt: str) -> dict:
    """Claude를 호출하고 JSON 응답을 파싱해서 반환. 코드펜스가 섞여 와도 방어적으로 파싱."""
    client = _client()
    resp = client.messages.create(
        model=MODEL,
        max_tokens=2000,
        system=system_prompt,
        messages=[{"role": "user", "content": user_prompt}],
    )
    text = "".join(block.text for block in resp.content if getattr(block, "type", "") == "text")
    cleaned = re.sub(r"^```(json)?|```$", "", text.strip(), flags=re.MULTILINE).strip()
    match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
    if not match:
        raise ValueError(f"채점 응답에서 JSON을 찾지 못했습니다. 원본 응답: {text[:500]}")
    return json.loads(match.group(0))


# ----------------------------------------------------------------------------
# 공통 시스템 프롬프트: 5가지 필수 반영 사항을 모두 명시
# ----------------------------------------------------------------------------
_BASE_SYSTEM_PROMPT = """\
너는 중학교 국어(설명하는 글 쓰기 / 영상 매체 제작) 서논술형 문항의 채점자다.
다음 5가지 원칙을 반드시 지켜서 채점한다.

1) [용어 없이도 의미 인정] 채점 기준에 제시된 표현(용어)이 답안에 그대로 없어도,
   요구된 의미(개념)가 문장에 담겨 있으면 정답으로 인정한다. 단어 매칭이 아니라 뜻으로 판단한다.
2) [방법의 기능 확인] 학생이 특정 설명 방법의 명칭을 표기했다면, 그 방법의 실제 기능적 특성
   (예: '인과'라면 원인→결과 관계, '비교와 대조'라면 공통점 또는 차이점 언급)이 문장에
   실제로 드러나는지 확인한다. 명칭만 맞고 기능이 다르면 오답(또는 명칭 오류)으로 처리한다.
3) [오개념 방지] 채점 기준에 제시된 '오개념 패턴'(한 개념의 특성을 반대/다른 개념 설명에
   사용하는 경우)이 답안에 나타나면 반드시 오답으로 처리하고, 어떤 오개념인지 reason에 명시한다.
4) [결론 방향 확인] 채점 기준에 제시된 '요구되는 결론/방향'이 답안에 명확히 드러나지 않으면
   설령 부분적으로 옳은 내용이 있어도 만점을 줄 수 없다. 결론이 아예 반대 방향이면 오답으로 처리한다.
5) [지문 외 배경지식 배제] 답안이 지문에 없는 외부 지식·주장을 추가했다면, 그 부분은 인정하지
   않는다. 단, 지문 내용을 다른 표현으로 재진술한 것은 배경지식이 아니라 정상적인 답안으로 본다.

반드시 순수 JSON만 출력한다. 코드펜스나 설명 문장을 앞뒤에 붙이지 않는다.
"""


def grade_blank_fill(set_id: str, blank_id: str, blank_criteria: dict, student_answer: str) -> dict:
    user_prompt = f"""
[채점 대상] {set_id} 문항1 - 빈칸 {blank_id} ({blank_criteria['label']})

[정답에 필요한 핵심 의미 요소]
{json.dumps(blank_criteria['required_concepts'], ensure_ascii=False)}

[인정 가능한 표현 예시]
{json.dumps(blank_criteria.get('accepted_examples', []), ensure_ascii=False)}

[불인정 예시 및 이유]
{json.dumps(blank_criteria.get('rejected_examples', []), ensure_ascii=False)}

[흔한 오개념 패턴 - 반드시 확인]
{blank_criteria.get('misconception_swap', '없음')}

[모범 답안]
{blank_criteria['model_answer']}

[이중 요소 필수 여부]
{"이 항목은 서로 다른 두 의미 요소(부정+긍정 등)가 '모두' 있어야 만점이며, 하나만 있으면 부분점수(0.5)만 인정." if blank_criteria.get('dual_requirement') else "해당 없음(단일 요소 판단)"}

[학생 답안]
{student_answer if student_answer.strip() else "(답안 없음)"}

다음 JSON 형식으로만 응답할 것 (배점은 1점 만점 기준):
{{
  "score": 0~1 사이 숫자 (정답=1, 부분점수=0.5, 오답=0),
  "verdict": "정답" 또는 "부분점수" 또는 "오답",
  "reason": "판단 근거를 한국어 1~2문장으로",
  "misconception_flag": "감지된 오개념 패턴 설명 또는 null"
}}
"""
    result = _call_claude_json(_BASE_SYSTEM_PROMPT, user_prompt)
    return {
        "total_score": result["score"],
        "max_score": 1,
        "items": [
            {
                "name": f"{blank_id} {blank_criteria['label']}",
                "score": result["score"],
                "max": 1,
                "verdict": result["verdict"],
                "reason": result["reason"],
                "misconception_flag": result.get("misconception_flag"),
            }
        ],
        "overall_feedback": result["reason"],
    }


def grade_method_writing(set_id: str, q_criteria: dict, sentence1: str, method1: str,
                          sentence2: str, method2: str) -> dict:
    from criteria import METHOD_DEFINITIONS

    user_prompt = f"""
[채점 대상] {set_id} 문항2 - 설명 방법을 활용한 이어쓰기

[문항 조건]
{json.dumps(q_criteria['conditions'], ensure_ascii=False, indent=2)}

[6가지 설명 방법의 기능 정의 - 명칭과 실제 기능 일치 여부 판단용]
{json.dumps(METHOD_DEFINITIONS, ensure_ascii=False, indent=2)}

[논리적 흐름 조건 필요 여부]
{q_criteria.get('flow_required', False)}
{q_criteria.get('flow_note', '')}

[흔한 오개념/위반 패턴 - 반드시 확인]
{json.dumps(q_criteria['misconceptions'], ensure_ascii=False, indent=2)}

[요구되는 결론/방향]
{q_criteria['conclusion_requirement']}

[방법별 모범 답안 참고]
{json.dumps(q_criteria['model_answers_by_method'], ensure_ascii=False, indent=2)}

[학생 답안]
(1) 문장: {sentence1 if sentence1.strip() else '(없음)'}
(1) 표기한 방법 명칭: {method1 if method1.strip() else '(없음)'}
(2) 문장: {sentence2 if sentence2.strip() else '(없음)'}
(2) 표기한 방법 명칭: {method2 if method2.strip() else '(없음)'}

다음 항목을 각각 1점 만점으로 채점하고 JSON으로만 응답:
- "different_methods": (1)(2)가 서로 다른 방법을 사용했는가 (명칭이 아니라 실제 기능 기준)
- "method_function_match": 표기한 방법 명칭과 실제 문장의 기능이 일치하는가 (두 문장 평균)
- "passage_only": 지문 내용만 활용했는가 (외부 배경지식 없음)
- "flow_and_conclusion": (흐름 조건이 있다면) 논리적 흐름이 자연스럽고, 요구되는 결론 방향이 드러나는가.
   흐름 조건이 없다면 결론 방향만 확인.

JSON 형식:
{{
  "different_methods": {{"score": 0~1, "reason": "..."}},
  "method_function_match": {{"score": 0~1, "reason": "..."}},
  "passage_only": {{"score": 0~1, "reason": "..."}},
  "flow_and_conclusion": {{"score": 0~1, "reason": "..."}},
  "misconception_flag": "감지된 오개념 또는 null",
  "overall_feedback": "학생에게 줄 종합 피드백 2~3문장"
}}
"""
    result = _call_claude_json(_BASE_SYSTEM_PROMPT, user_prompt)
    items = []
    name_map = {
        "different_methods": "서로 다른 방법 사용",
        "method_function_match": "방법 명칭-기능 일치",
        "passage_only": "지문 내용만 활용",
        "flow_and_conclusion": "논리적 흐름/결론 방향",
    }
    total = 0
    for key, name in name_map.items():
        sub = result[key]
        total += sub["score"]
        items.append({
            "name": name, "score": sub["score"], "max": 1,
            "verdict": "정답" if sub["score"] >= 1 else ("부분점수" if sub["score"] > 0 else "오답"),
            "reason": sub["reason"], "misconception_flag": None,
        })
    return {
        "total_score": total,
        "max_score": 4,
        "items": items,
        "overall_feedback": result.get("overall_feedback", ""),
        "misconception_flag": result.get("misconception_flag"),
    }


def grade_media_plan(set_id: str, q_criteria: dict, visual: str, visual_effect: str,
                      audio: str, audio_effect: str) -> dict:
    total_points = q_criteria.get("total_points", 6)
    breakdown = q_criteria.get("point_breakdown", {
        "시각 요소(Ⓐ) 타당성": total_points / 6,
        "시각 효과 서술(근거+연결)": total_points / 3,
        "청각 요소(Ⓑ) 타당성": total_points / 6,
        "청각 효과 서술(근거+연결)": total_points / 3,
    })

    user_prompt = f"""
[채점 대상] {set_id} 문항3 - 영상 기획안 시각/청각 요소 및 효과 서술 (총 {total_points}점)

[문항 조건]
{json.dumps(q_criteria['conditions'], ensure_ascii=False, indent=2)}

[반드시 반영해야 할 핵심 개념 축]
{json.dumps(q_criteria['required_concept_axes'], ensure_ascii=False)}
(이 문항은 개방형이라 정답이 하나가 아니다. 위 개념 축이 요소/효과 서술에 반영되어 있는지로 판단한다.)

[효과 서술에 지문 근거 인용이 필수인가]
{q_criteria['requires_passage_evidence']}
(참고: 이 항목이 True인 세트는 근거 언급이 없으면 효과 서술 점수를 절반 이하로 감점한다.
 False인 세트는 근거 인용이 없어도 요소-효과 간 논리적 연결만 있으면 만점 가능.)

[장면1과의 대비를 필수 조건으로 볼지 여부]
{q_criteria['contrast_with_scene1_required']}
(True면 대비되는 연출이 없을 경우 감점 대상. False면 가산 요소로만 취급하고 감점하지 않는다.)

[배점 배분]
{json.dumps(breakdown, ensure_ascii=False, indent=2)}

[모범 답안 예시(참고용, 유일 정답 아님)]
{json.dumps(q_criteria['model_answer'], ensure_ascii=False, indent=2)}

[학생 답안]
시각 요소(Ⓐ): {visual if visual.strip() else '(없음)'}
시각 효과: {visual_effect if visual_effect.strip() else '(없음)'}
청각 요소(Ⓑ): {audio if audio.strip() else '(없음)'}
청각 효과: {audio_effect if audio_effect.strip() else '(없음)'}

위 배점 배분 항목별로 채점하여 다음 JSON 형식으로만 응답 (score는 각 항목의 배점 한도 내 실수):
{{
  "시각 요소(Ⓐ) 타당성": {{"score": 0~배점, "reason": "..."}},
  "시각 효과 서술(근거+연결)": {{"score": 0~배점, "reason": "..."}},
  "청각 요소(Ⓑ) 타당성": {{"score": 0~배점, "reason": "..."}},
  "청각 효과 서술(근거+연결)": {{"score": 0~배점, "reason": "..."}},
  "overall_feedback": "학생에게 줄 종합 피드백 2~3문장"
}}
"""
    result = _call_claude_json(_BASE_SYSTEM_PROMPT, user_prompt)
    items = []
    total = 0
    for name, max_score in breakdown.items():
        sub = result[name]
        total += sub["score"]
        items.append({
            "name": name, "score": sub["score"], "max": max_score,
            "verdict": "정답" if sub["score"] >= max_score else ("부분점수" if sub["score"] > 0 else "오답"),
            "reason": sub["reason"], "misconception_flag": None,
        })
    return {
        "total_score": total,
        "max_score": total_points,
        "items": items,
        "overall_feedback": result.get("overall_feedback", ""),
    }
