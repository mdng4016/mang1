# -*- coding: utf-8 -*-
"""
서논술형 답안 자동 채점 앱 (Streamlit)
실행: streamlit run app.py
"""

import os

import streamlit as st

from criteria import CRITERIA, METHOD_DEFINITIONS
from grader import grade_blank_fill, grade_media_plan, grade_method_writing

st.set_page_config(page_title="서논술형 자동 채점", page_icon="✍️", layout="wide")

# ---------------------------------------------------------------------------
# API 키 설정
# ---------------------------------------------------------------------------
with st.sidebar:
    st.header("⚙️ 설정")
    key_input = st.text_input(
        "Anthropic API Key", type="password",
        value=os.environ.get("ANTHROPIC_API_KEY", ""),
        help="이 앱은 채점 판단을 위해 Claude API를 호출합니다. "
             "키는 이 세션에서만 사용되며 저장되지 않습니다.",
    )
    if key_input:
        os.environ["ANTHROPIC_API_KEY"] = key_input
    st.caption("키가 없다면 https://console.anthropic.com 에서 발급받으세요.")
    st.divider()
    st.caption("채점 기준은 `criteria.py` 파일을 수정해 자유롭게 갱신할 수 있습니다.")

st.title("✍️ 서논술형 답안 자동 채점")
st.caption("의미 기반 채점: 용어가 달라도 의미가 통하면 인정 · 오개념/결론 방향은 엄격히 확인")

col_set, col_q = st.columns(2)
set_id = col_set.selectbox("세트 선택", list(CRITERIA.keys()),
                            format_func=lambda s: f"{s} ({CRITERIA[s]['제재']})")
q_id = col_q.selectbox("문항 선택", ["문항1", "문항2", "문항3"])

set_data = CRITERIA[set_id]
q_data = set_data[q_id]

with st.expander("📖 지문 보기", expanded=False):
    st.write(set_data["passage"])

st.subheader(f"{set_id} {q_id} — {q_data['설명']}")

# ---------------------------------------------------------------------------
# 문항1: 빈칸 채우기
# ---------------------------------------------------------------------------
if q_id == "문항1":
    st.info("㉠~㉢ 각 빈칸에 답안을 입력하세요.")
    answers = {}
    for blank_id, blank in q_data["blanks"].items():
        answers[blank_id] = st.text_area(f"{blank_id} — {blank['label']}", height=70, key=f"{set_id}_{q_id}_{blank_id}")

    with st.expander("💡 모범 답안 (선택지별) 미리 보기"):
        for blank_id, blank in q_data["blanks"].items():
            st.markdown(f"**{blank_id}**: {blank['model_answer']}")

    if st.button("채점하기 ▶", type="primary", key="grade_q1"):
        try:
            total, maxt = 0, 0
            for blank_id, blank in q_data["blanks"].items():
                with st.spinner(f"{blank_id} 채점 중..."):
                    result = grade_blank_fill(set_id, blank_id, blank, answers[blank_id])
                total += result["total_score"]
                maxt += result["max_score"]
                item = result["items"][0]
                icon = {"정답": "✅", "부분점수": "🟡", "오답": "❌"}.get(item["verdict"], "•")
                st.markdown(f"{icon} **{item['name']}** — {item['verdict']} ({item['score']}/{item['max']}점)")
                st.caption(item["reason"])
                if item.get("misconception_flag"):
                    st.warning(f"⚠️ 오개념 감지: {item['misconception_flag']}")
            st.success(f"### 총점: {total} / {maxt}")
        except Exception as e:
            st.error(f"채점 중 오류: {e}")

# ---------------------------------------------------------------------------
# 문항2: 설명 방법 이어쓰기
# ---------------------------------------------------------------------------
elif q_id == "문항2":
    st.info("서로 다른 설명 방법으로 (1), (2) 문장을 작성하고, 사용한 방법을 선택하세요.")
    method_options = list(METHOD_DEFINITIONS.keys())

    c1, c2 = st.columns(2)
    with c1:
        sentence1 = st.text_area("(1) 문장", height=100, key=f"{set_id}_{q_id}_s1")
        method1 = st.selectbox("(1)에 사용한 설명 방법", method_options, key=f"{set_id}_{q_id}_m1")
    with c2:
        sentence2 = st.text_area("(2) 문장", height=100, key=f"{set_id}_{q_id}_s2")
        method2 = st.selectbox("(2)에 사용한 설명 방법", method_options, key=f"{set_id}_{q_id}_m2")

    with st.expander("💡 모범 답안 (방법별 선택지) 미리 보기"):
        for method, example in q_data["model_answers_by_method"].items():
            st.markdown(f"**{method}**: {example}")
        st.caption(f"※ 이 목록 외 다른 방법 조합도 조건을 충족하면 정답으로 인정됩니다: "
                   f"{', '.join(method_options)}")

    if st.button("채점하기 ▶", type="primary", key="grade_q2"):
        try:
            with st.spinner("채점 중..."):
                result = grade_method_writing(set_id, q_data, sentence1, method1, sentence2, method2)
            for item in result["items"]:
                icon = "✅" if item["score"] >= item["max"] else ("🟡" if item["score"] > 0 else "❌")
                st.markdown(f"{icon} **{item['name']}** — {item['score']}/{item['max']}점")
                st.caption(item["reason"])
            if result.get("misconception_flag"):
                st.warning(f"⚠️ 오개념 감지: {result['misconception_flag']}")
            st.success(f"### 총점: {result['total_score']} / {result['max_score']}")
            st.write("**종합 피드백**:", result["overall_feedback"])
        except Exception as e:
            st.error(f"채점 중 오류: {e}")

# ---------------------------------------------------------------------------
# 문항3: 영상 기획안
# ---------------------------------------------------------------------------
elif q_id == "문항3":
    st.info("시각 요소(Ⓐ)·청각 요소(Ⓑ)와 각각의 효과를 서술하세요.")
    if q_data["requires_passage_evidence"]:
        st.warning("이 문항은 효과 서술에 **반드시 지문 내용을 근거로 인용**해야 합니다.")

    visual = st.text_area("시각 요소 (Ⓐ)", height=80, key=f"{set_id}_{q_id}_visual")
    visual_effect = st.text_area("시각 효과 서술", height=80, key=f"{set_id}_{q_id}_veffect")
    audio = st.text_area("청각 요소 (Ⓑ)", height=80, key=f"{set_id}_{q_id}_audio")
    audio_effect = st.text_area("청각 효과 서술", height=80, key=f"{set_id}_{q_id}_aeffect")

    with st.expander("💡 모범 답안 예시 (개방형 문항 — 참고용)"):
        for k, v in q_data["model_answer"].items():
            st.markdown(f"**{k}**: {v}")

    if st.button("채점하기 ▶", type="primary", key="grade_q3"):
        try:
            with st.spinner("채점 중..."):
                result = grade_media_plan(set_id, q_data, visual, visual_effect, audio, audio_effect)
            for item in result["items"]:
                icon = "✅" if item["score"] >= item["max"] else ("🟡" if item["score"] > 0 else "❌")
                st.markdown(f"{icon} **{item['name']}** — {item['score']}/{item['max']}점")
                st.caption(item["reason"])
            st.success(f"### 총점: {result['total_score']} / {result['max_score']}")
            st.write("**종합 피드백**:", result["overall_feedback"])
        except Exception as e:
            st.error(f"채점 중 오류: {e}")
